# Texas Hold'em & Blackjack - PBT 4 | Java 5 prototype (Unity)

Prototype evidence for **Faza II - Product Design**. It implements the three Level/Puzzle Cards
(Texas Hold'em), the Feedback Matrix messages, and the scripted Blackjack parallel track.

## How to run it

1. Create a new Unity project (2021.3 LTS or newer; any template).
2. Copy this folder's `Assets/` into the project's `Assets/` folder.
3. Press **Play** in any scene. The game builds its own canvas and event system; no scene setup is needed.
4. Menu -> Level 1 / 2 / 3, or the Blackjack mode.

Run the checks: **Window > General > Test Runner > EditMode > Run All** (needs the Test Framework package,
which is included in the default templates).

Outside Unity, `python3 tools/verify_levels.py` replays every solution on a Python reference model of the same rules.

## What is in the code

| Area | Files (`Assets/Scripts/Core`) | Notes |
|---|---|---|
| Cards, hand evaluator | `Card.cs`, `HandEvaluator.cs` | Best 5 of 7, readable hand names ("Straight, Ace to 10") |
| Hold'em engine | `HoldemHand.cs` | Blinds, check/call/bet/raise, minimum raise, all-ins, side pots, showdown, refused actions with messages |
| Opponents | `BotPolicy.cs` | Deterministic rule bots: Passive, Level2Rule, Tight, Loose, Aggressive |
| Level Cards as data | `Levels.cs` | Fixed cards for Levels 1-3, pass conditions |
| Blackjack | `Blackjack.cs` | 3 scripted hands, dealer stands on 17, natural pays 3:2 |
| Instructions & feedback text | `Feedback.cs` | First-action prompt, river hint, outs helper, win/loss/pass messages |
| UI | `Assets/Scripts/UI/DemoApp.cs` | Self-building UGUI screens |
| Checks | `Assets/Tests/EditMode/LevelSolutionTests.cs` | Replays each card's solution and failing lines |

Level defects (duplicate card, wrong card count) throw `LevelConfigException` and show "Level configuration error"
instead of counting as a player loss.

## Playtest changes now in the prototype

These were the changes proposed in the Playtest Note. They are **implemented in code but not yet playtested**:

- Level 1/2/3: first-action prompt ("You owe 5 more chips to match the big blind. Press Call to stay in.")
- Level 2: river hint when a high card or pair arrives
- All levels: the opponents' cards are revealed after the hand; the loss message names the decisive street
- Level 2: pass message "Level passed. You kept 60 chips by folding when you were beaten."
- Level 3: optional outs and pot-odds helper on the flop and turn; the win message spells out the hand

## Rules the GDD must match (house rules of this prototype)

- No-limit betting; blinds 5/10; stacks 100; minimum bet or raise = the big blind or the last raise.
- **The human acts first on every post-flop street** (a simplification; standard heads-up order differs).
- Any raise re-opens the betting for everyone, including after a short all-in.
- Bots are deterministic, so the cards' solutions can be checked. In the scripted Level 3 hand the three bot styles
  all end up calling, so their differences are small there; they matter more in free play.

## Status - what was tested and what was not

**Done and checked**
- A Python reference model (`tools/verify_levels.py`) of the evaluator, engine, bots and cards passes all checks:
  Level 1 win (110 chips), Level 2 fold (60), calling the river (20), overbetting (0), Level 3 win (400), 12 outs of 47,
  Blackjack perfect run (135).

**Also checked in Unity (23/10/2026)**
- The project compiled and ran in Unity, and the playtest with Team 2 used this build.
- The EditMode tests ran in the Unity Test Runner: 15 of 15 passed.

**Not done**
- No automated tests for the UI screens (checked by playing only).

**Backlog (not implemented)**
- Free-play mode with random deals and a Hold'em table of up to 4 players.
- Custom bet amount input (the demo uses fixed bet buttons; "Bet 5" exists to show the refusal message).
- Blackjack double, split, insurance, and a bet-size choice.
- Sound, animation, card graphics (cards are text: `Jh`, `10s`).
- Owners: bots and 3D avatars are next week's objective; see the design document for the owner table.
