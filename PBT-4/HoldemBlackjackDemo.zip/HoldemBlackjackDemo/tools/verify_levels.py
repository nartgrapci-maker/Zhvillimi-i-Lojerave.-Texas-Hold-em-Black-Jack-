#!/usr/bin/env python3
"""Reference model of the demo rules (hand evaluator, betting engine, bot policies,
level cards, scripted Blackjack). It mirrors Assets/Scripts/Core one-to-one and checks
the solution traces from the Level/Puzzle Cards. Run: python3 tools/verify_levels.py"""
import itertools

RANKS = {**{str(i): i for i in range(2, 10)}, "T": 10, "J": 11, "Q": 12, "K": 13, "A": 14}

def card(s):
    s = s.replace("10", "T")
    return (RANKS[s[0].upper()], s[1].lower())

def cards(s):
    return [card(x) for x in s.split()]

def score5(cs):
    counts = {}
    for r, _ in cs:
        counts[r] = counts.get(r, 0) + 1
    flush = len({s for _, s in cs}) == 1
    keys = sorted((c * 100 + r for r, c in counts.items()), reverse=True)
    straight = 0
    if len(keys) == 5:
        ranks = [k - 100 for k in keys]
        if ranks[0] - ranks[4] == 4:
            straight = ranks[0]
        elif ranks == [14, 5, 4, 3, 2]:
            straight = 5
    c0 = keys[0] // 100
    c1 = keys[1] // 100 if len(keys) > 1 else 0
    if straight and flush: cat = 8
    elif c0 == 4: cat = 7
    elif c0 == 3 and c1 == 2: cat = 6
    elif flush: cat = 5
    elif straight: cat = 4
    elif c0 == 3: cat = 3
    elif c0 == 2 and c1 == 2: cat = 2
    elif c0 == 2: cat = 1
    else: cat = 0
    k = [0] * 5
    if cat in (4, 8): k[0] = straight
    else:
        for i, key in enumerate(keys): k[i] = key % 100
    return (cat << 20) | (k[0] << 16) | (k[1] << 12) | (k[2] << 8) | (k[3] << 4) | k[4]

def evaluate(cs):
    return max(score5(c) for c in itertools.combinations(cs, 5))

PLURAL = {2:"Twos",3:"Threes",4:"Fours",5:"Fives",6:"Sixes",7:"Sevens",8:"Eights",9:"Nines",10:"Tens",11:"Jacks",12:"Queens",13:"Kings",14:"Aces"}
SHORT = {11:"Jack",12:"Queen",13:"King",14:"Ace"}
def short(r): return SHORT.get(r, str(r))
def straight_text(top): return f"{short(top)} to " + ("Ace" if top == 5 else short(top - 4))
def describe(sc):
    cat = sc >> 20; k0 = (sc >> 16) & 15; k1 = (sc >> 12) & 15
    return {0: lambda: f"{short(k0)}-high", 1: lambda: f"Pair of {PLURAL[k0]}",
            2: lambda: f"Two pair, {PLURAL[k0]} and {PLURAL[k1]}", 3: lambda: f"Three {PLURAL[k0]}",
            4: lambda: "Straight, " + straight_text(k0), 5: lambda: f"Flush, {short(k0)}-high",
            6: lambda: f"Full house, {PLURAL[k0]} over {PLURAL[k1]}", 7: lambda: f"Four {PLURAL[k0]}",
            8: lambda: "Royal flush" if k0 == 14 else "Straight flush, " + straight_text(k0)}[cat]()

PRE, FLOP, TURN, RIVER, DONE = 0, 1, 2, 3, 4
class Seat:
    def __init__(s, name, human, stack, hole, style):
        s.name, s.human, s.stack, s.hole, s.style = name, human, stack, hole, style
        s.folded = s.allin = False; s.street = s.total = 0

class Hand:
    def __init__(s, seats, board, sb_seat, bb_seat, sb, bb, pre_first):
        s.seats, s.board, s.sb, s.bb = seats, board, sb, bb
        allc = [c for st in seats for c in st.hole] + board
        if len(set(allc)) != len(allc) or len(board) != 5: raise ValueError("level config error")
        s.street = PRE; s.current = 0; s.minraise = bb; s.need = [False] * len(seats); s.result = None
        s.post(sb_seat, sb); s.post(bb_seat, bb); s.current = bb
        s.start_round(pre_first)
    def post(s, i, amt):
        st = s.seats[i]; a = min(amt, st.stack); st.stack -= a; st.street += a; st.total += a
        st.allin = st.stack == 0
    @property
    def pot(s): return sum(x.total for x in s.seats)
    @property
    def board_count(s): return [0, 3, 4, 5, 5][s.street]
    def visible(s): return s.board[:s.board_count]
    def to_call(s, i): return min(s.current - s.seats[i].street, s.seats[i].stack)
    def can_act(s): return [i for i, x in enumerate(s.seats) if not x.folded and not x.allin]
    def start_round(s, first):
        s.need = [i in s.can_act() for i in range(len(s.seats))]
        if len(s.can_act()) < 2:
            s.need = [False] * len(s.seats); s.advance(); return
        s.actor = first if s.need[first] else s.next_actor(first)
    def next_actor(s, frm):
        n = len(s.seats)
        for k in range(1, n + 1):
            j = (frm + k) % n
            if s.need[j]: return j
        return -1
    def validate(s, a):
        st = s.seats[s.actor]; kind = a[0]
        if kind == "check" and s.current != st.street: return "cannot check"
        if kind == "call" and s.to_call(s.actor) <= 0: return "nothing to call"
        if kind == "bet":
            t = a[1]
            if t <= s.current: return "must exceed current bet"
            if t > st.street + st.stack: return "not enough chips"
            if t < s.current + s.minraise and t != st.street + st.stack: return "minimum raise"
        return None
    def apply(s, a):
        err = s.validate(a); assert err is None, err
        i = s.actor; st = s.seats[i]; kind = a[0]
        if kind == "fold": st.folded = True
        elif kind == "call": s.post(i, s.to_call(i))
        elif kind == "bet":
            t = a[1]; s.post(i, t - st.street)
            if t - s.current >= s.minraise: s.minraise = t - s.current
            s.current = t
            s.need = [j != i and not x.folded and not x.allin for j, x in enumerate(s.seats)]
        s.need[i] = False
        if sum(1 for x in s.seats if not x.folded) == 1: s.settle(False); return
        nxt = s.next_actor(i)
        if nxt >= 0: s.actor = nxt
        else: s.advance()
    def advance(s):
        while True:
            if s.street == RIVER: s.settle(True); return
            s.street += 1
            for x in s.seats: x.street = 0
            s.current = 0; s.minraise = s.bb
            s.need = [i in s.can_act() for i in range(len(s.seats))]
            if len(s.can_act()) >= 2:
                s.actor = s.next_actor(-1 % len(s.seats)) if not s.need[0] else 0; return
            s.need = [False] * len(s.seats)
    def made_cat(s, i):
        h = s.seats[i].hole
        if s.board_count < 3: return 1 if h[0][0] == h[1][0] else 0
        return evaluate(h + s.visible()) >> 20
    def settle(s, showdown):
        n = len(s.seats); wins = [0] * n
        sc = [evaluate(x.hole + s.board) if (showdown and not x.folded) else -1 for x in s.seats]
        prev = 0
        for lvl in sorted({x.total for x in s.seats if x.total > 0}):
            amt = sum(min(x.total, lvl) - min(x.total, prev) for x in s.seats)
            el = [i for i, x in enumerate(s.seats) if not x.folded and x.total >= lvl] or [i for i, x in enumerate(s.seats) if not x.folded]
            if len(el) > 1 and showdown:
                b = max(sc[i] for i in el); w = [i for i in el if sc[i] == b]
            else: w = el
            for i in w: wins[i] += amt // len(w)
            wins[w[0]] += amt % len(w); prev = lvl
        for i, x in enumerate(s.seats): x.stack += wins[i]
        s.street = DONE
        s.result = {"by_fold": not showdown, "wins": wins, "names": [describe(v) if v >= 0 else None for v in sc]}

def decide(h, i):
    st = h.seats[i]; style = st.style; to_call = h.to_call(i); pot = h.pot; cat = h.made_cat(i); pre = h.street == PRE
    if to_call <= 0:
        if pre: return ("check",)
        want = {"rule2": h.street == RIVER and cat >= 3, "tight": cat >= 3, "aggr": True}.get(style, False)
        if not want: return ("check",)
        total = min(h.current + max(h.minraise, pot // 2), st.street + st.stack)
        return ("bet", total) if total > h.current else ("check",)
    if pre: return ("call",) if (to_call <= 2 * h.bb or style in ("passive", "loose")) else ("fold",)
    small = to_call * 2 <= pot - to_call
    if style in ("passive", "loose"): return ("call",)
    if style == "rule2": return ("call",) if (cat >= 1 or small) else ("fold",)
    if style == "tight": return ("call",) if (cat >= 3 or (cat >= 1 and small)) else ("fold",)
    return ("call",) if cat >= 1 else ("fold",)

def level(n):
    if n == 1: seats = [Seat("You", True, 100, cards("Js Jd"), ""), Seat("Bot", False, 100, cards("Ac 5c"), "passive")]; b = "Jh 4c 8d 2s 9d"; f = 0
    if n == 2: seats = [Seat("You", True, 100, cards("Ah Kd"), ""), Seat("Bot", False, 100, cards("Qc Qd"), "rule2")]; b = "Ks 7c 2d 9h Qs"; f = 0
    if n == 3:
        seats = [Seat("You", True, 100, cards("As Ks"), ""), Seat("Bot A", False, 100, cards("Qd Qc"), "tight"),
                 Seat("Bot B", False, 100, cards("9s 8s"), "loose"), Seat("Bot C", False, 100, cards("Kh Jh"), "aggr")]
        b = "Qs Js 3d Tc 2d"; f = 2
    return Hand(seats, cards(b), 0, 1, 5, 10, f)

def play(n, script):
    h = level(n); script = list(script)
    while h.street != DONE:
        if h.seats[h.actor].human: h.apply(script.pop(0))
        else: h.apply(decide(h, h.actor))
    assert not script, f"unused actions: {script}"
    return h

CHECK, CALL, FOLD = ("check",), ("call",), ("fold",)
def bet(t): return ("bet", t)
fails = 0
def expect(label, got, want):
    global fails
    ok = got == want; fails += (not ok)
    print(("PASS " if ok else "FAIL ") + f"{label}: {got}" + ("" if ok else f" (expected {want})"))

# evaluator spot checks
expect("Broadway text", describe(evaluate(cards("As Ks Qs Js Tc 3d 2d"))), "Straight, Ace to 10")
expect("Wheel text", describe(evaluate(cards("As 2d 3c 4h 5s Kd 9c"))), "Straight, 5 to Ace")
expect("Three Jacks", describe(evaluate(cards("Js Jd Jh 4c 8d 2s 9d"))), "Three Jacks")
expect("Q-high straight < Broadway", evaluate(cards("9s 8s Qs Js 3d Tc 2d")) < evaluate(cards("As Ks Qs Js 3d Tc 2d")), True)

h = play(1, [CALL, CHECK, CHECK, CHECK]); expect("L1 solution: final stack", h.seats[0].stack, 110)
expect("L1 hand names", (h.result["names"][0], h.result["names"][1]), ("Three Jacks", "Ace-high"))
h = play(1, [FOLD]); expect("L1 folding preflop stack (fail, needs >100)", h.seats[0].stack, 95)

h = play(2, [CALL, bet(10), bet(20), CHECK, FOLD]); expect("L2 solution: stack (pass >=60)", h.seats[0].stack, 60)
h = play(2, [CALL, bet(10), bet(20), CHECK, CALL]); expect("L2 call river: stack", h.seats[0].stack, 20)
h = play(2, [CALL, bet(30), bet(60)]); expect("L2 overbet: stack", h.seats[0].stack, 0)
h = play(2, [CALL, bet(10), bet(20), CHECK, CALL]); expect("L2 losing hand names", (h.result["names"][0], h.result["names"][1]), ("Pair of Kings", "Three Queens"))

h = play(3, [CALL, CHECK, CALL, CHECK, CALL, CHECK, CALL]); expect("L3 solution: stack (pass >100)", h.seats[0].stack, 400)
expect("L3 hand names", h.result["names"], ["Straight, Ace to 10", "Three Queens", "Straight, Queen to 8", "Pair of Jacks"])
h = play(3, [CALL, CHECK, FOLD]); expect("L3 fold on flop: stack (fail)", h.seats[0].stack, 90)

# outs on the Level 3 flop
known = cards("As Ks Qs Js 3d")
unseen = [(r, s) for r in range(2, 15) for s in "cdhs" if (r, s) not in known]
outs = sum(1 for c in unseen if evaluate(known + [c]) >> 20 >= 4)
expect("L3 flop outs (of 47)", (outs, len(unseen)), (12, 47))

# scripted Blackjack
def total(cs):
    t = sum(10 if r in (11, 12, 13) else (11 if r == 14 else r) for r, _ in cs); aces = sum(1 for r, _ in cs if r == 14)
    while t > 21 and aces: t -= 10; aces -= 1
    return t
def bj(player, dealer, draws, hit_first):
    p, d, q = cards(player), cards(dealer), cards(draws)
    if total(p) == 21 and len(p) == 2: return 0 if total(d) == 21 else 15
    if hit_first:
        p.append(q.pop(0))
        if total(p) > 21: return -10
    while total(d) < 17: d.append(q.pop(0))
    if total(d) > 21 or total(p) > total(d): return 10
    return 0 if total(p) == total(d) else -10
expect("BJ hand 1 hit", bj("10s 6h", "10d 7c", "5c", True), 10)
expect("BJ hand 2 stand", bj("Kc 7s", "6d 10h", "9c", False), 10)
expect("BJ hand 2 hit (bust)", bj("Kc 7s", "6d 10h", "9c", True), -10)
expect("BJ hand 3 natural", bj("As Kh", "10c 7d", "", False), 15)
expect("BJ perfect run chips", 100 + 10 + 10 + 15, 135)
print("\nALL CHECKS PASSED" if not fails else f"\n{fails} CHECK(S) FAILED")
raise SystemExit(1 if fails else 0)
